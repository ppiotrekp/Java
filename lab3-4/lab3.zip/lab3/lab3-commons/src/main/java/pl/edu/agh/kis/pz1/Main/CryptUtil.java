package pl.edu.agh.kis.pz1.Main;

import java.math.BigInteger;
import java.security.MessageDigest;

public class CryptUtil {

    public static void main(String[] args) {

    }
    public static String getSHA512(String input){

        String toReturn = null;
        try {
            MessageDigest digest = MessageDigest.getInstance("SHA-512");
            digest.reset();
            digest.update(input.getBytes("utf8"));
            toReturn = String.format("%0128x", new BigInteger(1, digest.digest()));
        } catch (Exception e) {
            e.printStackTrace();
        }

        return toReturn;
    }

    public static double addition(double a, double b) {
        return a+b;
    }
}
