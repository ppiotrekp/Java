package org.example;

import java.util.concurrent.Semaphore;
//Semafory kontrolują limit wątków, do których chcemy mieć dostęp

/**
 * Klasa reprezentujaca zasoby,
 * ktore sa dostepne dla czytelnikow i pisarzy,
 * ten dostep jest kontrolowany przez semafory
 * mutex i resource.
 */

public class Resources implements RWLock {
    private int readerCount = 0;  // liczba aktywnych czytelników
    private Semaphore mutex = new Semaphore(1);  // kontroluje dostęp do liczby czytelnikow
    private Semaphore resource = new Semaphore(1);     // Kontroluje dostęp do zasobów


    /**
     * Metoda pozwalajaca na czytanie zasobu przez czytelnika,
     * kontrolujaca dostep do zasobu przez semafory.
     * @param numberOfReaders
     */
    public void acquireReadLock(int numberOfReaders) {
        try{
            // wykluczeni czytelnicy, bo readerCount=0, wątek blokowany
            mutex.acquire();
        }
        catch (InterruptedException e) {}

        readerCount++;

        // jeśli jest pierwszy czytelnik
        // to znaczy ze zasob jest odczytywany
        if (readerCount == 1){
            try{
                resource.acquire();
            }
            catch (InterruptedException e) {}
        }

        System.out.println("Czytelnik " + numberOfReaders + " czyta w tym momencie. Liczba czytelników w czytelni:  " + readerCount);
        //wzajemne pozwolenie do czytania zasobow przez czytelnika
        mutex.release();
    }


    /**
     * Metoda, za pomoca ktorej czytelnik konczy czytanie
     * i opuszcza czytelnie.
     * @param numberOfReaders
     */
    public void releaseReadLock(int numberOfReaders) {
        try{
            //wzajemne pozwolenie do czytania zasobow przez czytelnika
            mutex.acquire();
        }
        catch (InterruptedException e) {}

        readerCount--;

        // jesli jest jeden pisarz
        // zasoby nie moga byc odczytywane przez czytelnika
        if (readerCount == 0){
            resource.release();
        }

        System.out.println("Czytelnik " + numberOfReaders + " skonczyl czytac. Liczba czytelników w czytelni: " + readerCount);

        //wzajemne pozwolenie do czytania zasobow przez czytelnika
        mutex.release();
    }

    /** Metoda pozwalajaca na pisanie przez pisarza.
     *
     * @param numberOfWriters
     */
    public void acquireWriteLock(int numberOfWriters) {
        try{
            resource.acquire();
        }
        catch (InterruptedException e) {}
        System.out.println("Pisarz " + numberOfWriters + " pisze w tym momencie.");
    }


    /**
     * Metoda, za pomoca ktorej
     * pisarz opuszcza czytelnie.
     * @param writerNum
     */
    public void releaseWriteLock(int writerNum) {
        System.out.println("Pisarz " + writerNum + " skonczyl pisac.");
        resource.release();
    }
}
