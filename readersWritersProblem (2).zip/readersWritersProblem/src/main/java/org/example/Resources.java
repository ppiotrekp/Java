package org.example;

//import jdk.jpackage.internal.Log;

import java.util.concurrent.Semaphore;
import java.util.logging.Level;
import java.util.logging.Logger;
//Semafory kontrolują limit wątków, do których chcemy mieć dostęp

/**
 * Klasa reprezentujaca zasoby,
 * ktore sa dostepne dla czytelnikow i pisarzy,
 * ten dostep jest kontrolowany przez semafory
 * mutex i resource.
 */

public class Resources implements RWLock {
    private int readerCount;  // liczba aktywnych czytelników
    private Semaphore readerSem;  // kontroluje dostęp do liczby czytelnikow
    private Semaphore resource;    // Kontroluje dostęp do zasobów
    private final Logger logger = Logger.getLogger(getClass().getName());

    public Resources() {
        readerCount = 0;
        readerSem = new Semaphore((1));
        resource = new Semaphore(1);
    }

    /**
     * Metoda pozwalajaca na czytanie zasobu przez czytelnika,
     * kontrolujaca dostep do zasobu przez semafory.
     * @param numberOfReaders
     */
    public void acquireReadLock(int numberOfReaders) {
        try{
            // wykluczeni czytelnicy, bo readerCount=0, wątek blokowany
            readerSem.acquire();
        }
        catch (InterruptedException e) {
            logger.log(Level.INFO, "Blad", e);
        }

        readerCount++;

        // jeśli jest pierwszy czytelnik
        // to znaczy ze zasob jest odczytywany
        if (readerCount == 1){ //jezeli readerCount != 1 to pisarz pisze kiedy chce
            try{
                resource.acquire();
            }
            catch (InterruptedException e) {}
        }

        logger.info("Czytelnik " + numberOfReaders + " czyta w tym momencie. Liczba czytelników w czytelni:  " + readerCount);
        readerSem.release();
    }


    /**
     * Metoda, za pomoca ktorej czytelnik konczy czytanie
     * i opuszcza czytelnie.
     * @param numberOfReaders
     */
    public void releaseReadLock(int numberOfReaders) {
        try{
            //wzajemne wykluczenie dla czytelnikow
            readerSem.acquire();
        }
        catch (InterruptedException e) {}

        readerCount--;

        // jesli nie ma czytelnikow
        // zasoby nie moga byc odczytywane przez czytelnika
        if (readerCount == 0){
            resource.release();
        }

        System.out.println("Czytelnik " + numberOfReaders + " skonczyl czytac. Liczba czytelników w czytelni: " + readerCount);

        //wzajemne wykluczenie dla czytelnikow
        readerSem.release();
    }

    /** Metoda pozwalajaca na pisanie przez pisarza.
     *
     * @param numberOfWriters
     */
    public void acquireWriteLock(int numberOfWriters) {
        try{
            resource.acquire();
        }
        catch (InterruptedException e) {}
        System.out.println("Pisarz " + numberOfWriters + " pisze w tym momencie.");
    }


    /**
     * Metoda, za pomoca ktorej
     * pisarz opuszcza czytelnie.
     * @param writerNum
     */
    public void releaseWriteLock(int writerNum) {
        logger.info("Pisarz " + writerNum + " skonczyl pisac.");
        resource.release();
    }
}
