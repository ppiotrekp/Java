package pl.edu.agh.kis.pz1.Main;

//import static org.junit.Assert.assertEquals;
//import static org.junit.Assert.assertTrue;
import static org.junit.Assert.*;;

import org.junit.Test;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */

    private final CryptUtil cryptUtil = new CryptUtil();
    @Test
    public void shouldAnswerWithTrue()
    {
        assertTrue( true );
    }

    @Test
    public void testForAddition() {
        assertEquals(4,cryptUtil.addition(3,2),2);
        //assertEquals(23.0, 250.0, 0.0);

    }


}
