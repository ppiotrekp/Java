package pl.edu.agh.kis.pz1.Main;

import java.util.Objects;

public class Card {
    public enum Suit { //kolory kart
        HEARTS,
        DIAMONDS,
        CLUBS,
        SPADES
    }
    public enum Rank { // rangi kart
        TWO,
        THREE,
        FOUR,
        FIVE,
        SIX,
        SEVEN,
        EIGHT,
        NINE,
        TEN,
        JACK,
        QUEEN,
        KING,
        ACE
    }

    String suit;
    String rank;

    public Card(Suit suit, Rank rank) {
        this.rank = rank.name(); //stringowi przypisuje enuma
        this.suit = suit.name();
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Card)) return false;
        Card card = (Card) o;
        return Objects.equals(suit, card.suit) && Objects.equals(rank, card.rank);
    }

    @Override
    public int hashCode() {
        return Objects.hash(suit, rank);
    }
}
