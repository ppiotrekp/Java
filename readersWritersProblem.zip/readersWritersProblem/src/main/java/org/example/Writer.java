package org.example;

/**
 * Klasa reprezentujaca pisarza
 */

public class Writer extends Thread {
    private Resources resource;
    private int writerNum;

    /**
     * Konstruktor, w ktorym okreslony jest numer pisarza
     * i zasob, z ktorego moze korzystac.
     * @param numberOfWriters
     * @param resource
     */
    public Writer(int numberOfWriters, Resources resource) {
        this.writerNum = numberOfWriters;
        this.resource = resource;
    }

    /**
     * Metoda po utworzeniu i uruchomieniu watku,
     * zakonczy swoje dzialanie, gdy watek zostanie
     * przerwany przez metode releaseWriteLock.
     */
    @Override
    public void run() {
        while (true){
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("pisarz " + writerNum + " chce pisac.");
            resource.acquireWriteLock(writerNum); //pisarz moze pisac
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            resource.releaseWriteLock(writerNum);
        }
    }
}