package org.example;

/**
 * Klasa reprezentujaca czytelnika.
 */
public class Reader extends Thread {

    private Resources resource;
    private int readerNum;

    /**
     * Konstruktor, w ktorym okreslony jest numer czytelnika
     * i zasob z ktorego moze korzystac.
     * @param readerNum
     * @param resource
     */
    public Reader(int readerNum, Resources resource) {
        this.readerNum = readerNum;
        this.resource = resource;
    }

    /**
     * Metoda po utworzeniu i uruchomieniu watku,
     * zakonczy swoje dzialanie, gdy watek zostanie
     * przerwany przez metode releaseReadLock.
     */
    @Override
    public void run() {
        while (true) {
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            System.out.println("czytelnik " + readerNum + " chce czytac.");
            resource.acquireReadLock(readerNum); //dostęp do czytania
            try {
                Thread.sleep(2000);
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
            resource.releaseReadLock(readerNum);
        }
    }
}
