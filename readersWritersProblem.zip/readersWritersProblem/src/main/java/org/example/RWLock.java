package org.example;

/**
 * interfejs, w ktorym zdefiniowane sa metody
 * sluzace do zarzadzania procesami.
 */

public interface RWLock{
    public void acquireReadLock(int readerNum) throws InterruptedException;
    public void acquireWriteLock(int readerNum) throws InterruptedException;
    public void releaseReadLock(int readerNum) throws InterruptedException;
    public void releaseWriteLock(int readerNum);
}