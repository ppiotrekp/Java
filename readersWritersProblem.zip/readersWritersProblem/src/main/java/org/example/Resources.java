package org.example;

import java.util.concurrent.Semaphore;
//Semafory kontrolują limit wątków, ktore maja miec dostep do zasobow

/**
 * Klasa reprezentujaca zasoby,
 * ktore sa dostepne dla czytelnikow i pisarzy,
 * ten dostep jest kontrolowany przez semafory
 */

public class Resources implements RWLock {
    private int readerCount;  // liczba aktywnych czytelników
    private int writerCount;
    private Semaphore readerSem;  // kontroluje dostęp do liczby czytelnikow
    private Semaphore writerSem;    // Kontroluje dostęp do liczby pisarzy

    // liczba watkow dopuszczonych przez semafor < permits to semafor ten watek dopusci,
    // w innym przypadku musi czekac az na innym watku krzystajacym z zasobu nie pojawi sie release
    public Resources() {
        readerCount = 0;
        writerCount = 0;
        readerSem = new Semaphore(1);
        writerSem = new Semaphore(1);
    }

    /**
     * Metoda pozwalajaca na czytanie zasobu przez czytelnika,
     * kontrolujaca dostep do zasobu przez semafory.
     * @param numberOfReaders
     */
    public void acquireReadLock(int numberOfReaders) throws InterruptedException {
        readerSem.acquire(); //zajmuje zasob, jezeli jest wolny przechodzi dalej, w tym przypadku pozwala wejsc czytelnikowi

        if (readerCount == 0) { //jesli nie ma zadnego czytelnika, to pisarz moze zajac zasob
            writerSem.acquire();
        }

        readerCount++;
        System.out.println("Czytelnik " + numberOfReaders + " czyta w tym momencie. Liczba czytelników w czytelni:  " + readerCount);
        readerSem.release(); //zwalnia zasob dla innych watkow, bez tego zatrzymuje sie na 1 czytelniku
    }

    /**
     * Metoda, za pomoca ktorej czytelnik konczy czytanie
     * i opuszcza czytelnie.
     * @param numberOfReaders
     */
    public void releaseReadLock(int numberOfReaders) throws InterruptedException {
        readerSem.acquire();
        readerCount--;

        if (readerCount == 0){
            writerSem.release();
        }

        System.out.println("Czytelnik " + numberOfReaders + " skonczyl czytac. Liczba czytelników w czytelni: " + readerCount);
        readerSem.release(); //czytelnik zwalnia zasob
    }

    /** Metoda pozwalajaca na pisanie przez pisarza.
     *
     * @param numberOfWriters
     */
    public void acquireWriteLock(int numberOfWriters) {
        try{
            writerSem.acquire();
        }
        catch (InterruptedException e) {}
        writerCount++;
        System.out.println("Pisarz " + numberOfWriters + " pisze w tym momencie. Liczba pisarzy w czytelni: " + writerCount + ", liczba czytelnikow: " + readerCount);
    }

    /**
     * Metoda, za pomoca ktorej
     * pisarz opuszcza czytelnie.
     * @param writerNum
     */
    public void releaseWriteLock(int writerNum) {
        writerCount--;
        System.out.println("Pisarz " + writerNum + " skonczyl pisac. Liczba pisarzy w czytelni: " + writerCount + ", liczba czytelnikow: " + readerCount);
        writerSem.release();
    }
}
