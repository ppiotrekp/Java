package pl.edu.agh.kis.pz1.Main;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello World!" );
        Deck deck = new Deck();
        deck.shuffle();
        deck.factory();
    }
}
