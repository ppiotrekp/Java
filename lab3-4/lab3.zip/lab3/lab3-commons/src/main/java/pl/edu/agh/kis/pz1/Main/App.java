package pl.edu.agh.kis.pz1.Main;

import static pl.edu.agh.kis.pz1.Main.CryptUtil.getSHA512;

/**
 * Hello world!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        String inputValue = "this is an example";

        String sha512 = getSHA512( inputValue );

        System.out.println("The SHA-512 of \"" + inputValue + "\" is:");
        System.out.println(sha512);
        System.out.println();

        // With Apache commons
        sha512 = org.apache.commons.codec.digest.DigestUtils.sha512Hex(inputValue);

        System.out.println("The SHA-512 of \"" + inputValue + "\" is:");
        System.out.println(sha512);
        System.out.println( "Hello World!" );
    }
}
