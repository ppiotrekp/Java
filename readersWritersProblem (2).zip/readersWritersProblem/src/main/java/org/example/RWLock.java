package org.example;

/**
 * interfejs, w ktorym zdefiniowane sa metody
 * sluzace do zarzadzania procesami.
 */

public interface RWLock{
    public void acquireReadLock(int numberOfReaders);
    public void acquireWriteLock(int numberOfWriters);
    public void releaseReadLock(int numberOfReaders);
    public void releaseWriteLock(int numberOfWriters);
}