package org.example;

/**
 * interfejs, w ktorym zdefiniowane sa metody
 * sluzace do zarzadzania procesami.
 */

public interface RWLock{
    public abstract void acquireReadLock(int numberOfReaders);
    public abstract void acquireWriteLock(int numberOfWriters);
    public abstract void releaseReadLock(int numberOfReaders);
    public abstract void releaseWriteLock(int numberOfWriters);
}