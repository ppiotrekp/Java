package pl.edu.agh.kis.pz1.Main;

/**
 * by ppyrczak
 */

import java.util.ArrayList;
import java.util.Collections;


public  class Deck {
    public ArrayList<Card> cards = new ArrayList<>(52);

    public Deck(String deck) {
        for (Card.Suit suit : Card.Suit.values() ) {
            for (Card.Rank rank : Card.Rank.values()) {
                this.cards.add(new Card(suit, rank));
            }
        }
        System.out.println(deck);
    }

    /**
     * this is a conctructor which adds cards to an array
     */

    public Deck() {}

    /**
     * this is a default constructor
     */

    public void factory() {
        System.out.println("Sorting !");
        this.cards.clear();
        Deck deck = new Deck("new deck !");
    }

    /**
     * this is a factory method which sorts cards
     */

    public void shuffle() {
        System.out.println("Shuffling !");
        Collections.shuffle(this.cards);
    }

    /**
     * this is a shuffle method, cards are set randomly
     */
}
