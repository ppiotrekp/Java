package org.example;

import java.util.ArrayList;
import java.util.List;

/**
 * Klasa, w ktorej tworzone są wątki
 * dla czytelnika i pisarza oraz zasób
 * do ktorego jest kontrolowany dostęp
 *
 */
public class App 
{
    public static final int numOfReaders = 5;
    public static final int numOfWriters = 1;

    public static void main(String args[]){
        Resources resource = new Resources();

        Thread[] readerArray = new Thread[numOfReaders];
        Thread[] writerArray = new Thread[numOfWriters];

        for (int i = 0; i < numOfReaders; i++) {
            readerArray[i] = new Thread(new Reader(i, resource));
            readerArray[i].start();
        }

        for (int i = 0; i < numOfWriters; i++) {
            writerArray[i] = new Thread(new Writer(i, resource));
            writerArray[i].start();
        }
    }
}
